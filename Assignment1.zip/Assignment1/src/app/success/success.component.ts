import { Component } from "@angular/core";

@Component({
    selector:'.app-success',
    templateUrl:'./success.component.html',
    styles:[`h3{
        color:green;
    }`]

})
export class SuccessComponent{
    
}